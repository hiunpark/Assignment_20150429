package com.samsung.homework01;

/**
 * @author 박서연
 * 점수 VO
 */
public class JumsuVO {
	private String name;
	private int kor;
	private int eng;
	private int math;
	private int java;
	
	private int total;
	private int avg;
	public JumsuVO() {
		super();
	}
	public JumsuVO(String name, int kor, int eng, int math, int java,
			int total, int avg) {
		super();
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.math = math;
		this.java = java;
		this.total = total;
		this.avg = avg;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public int getJava() {
		return java;
	}
	public void setJava(int java) {
		this.java = java;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getAvg() {
		return avg;
	}
	public void setAvg(int avg) {
		this.avg = avg;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("JumsuVO [name=");
		builder.append(name);
		builder.append(", kor=");
		builder.append(kor);
		builder.append(", eng=");
		builder.append(eng);
		builder.append(", math=");
		builder.append(math);
		builder.append(", java=");
		builder.append(java);
		builder.append(", total=");
		builder.append(total);
		builder.append(", avg=");
		builder.append(avg);
		builder.append("]");
		return builder.toString();
	}
}
