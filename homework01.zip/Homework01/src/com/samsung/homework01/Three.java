package com.samsung.homework01;

/**
 * 
 * @author 박서연
 * jumsu interface를 구현하여 3개의 성적을 처리하는 클래스
 * 
 */
public class Three  implements Jumsu{
	private JumsuVO vo = null;
	
	public Three(String name, int kor, int eng, int math) {
		vo = new JumsuVO();
		vo.setName(name);
		vo.setKor(kor);
		vo.setEng(eng);
		vo.setMath(math);
	}
	public void onTotal() {
		vo.setTotal(vo.getEng()+vo.getKor()+vo.getMath());
	}
	public void onAvg() {
		vo.setAvg(vo.getTotal()/3);
	}
	@Override
	public void display(){
		onTotal();
		onAvg();
		System.out.println(vo.getName() + "의 총점은 " + vo.getTotal() + "이고 평균은 " + vo.getAvg());
	}
}
