package com.samsung.homework01;

/**
 * 
 * @author 박서연
 * factory
 *
 */
public class JumsuFactory {
	public Object getBean(){
		Jumsu jumsu = new Three("박서연", 100, 100, 100);
		return jumsu;
	}
	public Object getBean4(){
		Jumsu jumsu = new Four("신성진", 70, 80, 75, 100);
		return jumsu;
	}
}
