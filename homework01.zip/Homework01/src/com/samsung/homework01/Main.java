package com.samsung.homework01;
/**
 * 
 * @author 박서연
 * main 클래스
 */
public class Main {
	public static void main(String[] args) {
		JumsuFactory factory = new JumsuFactory();
		Jumsu jumsu = (Jumsu) factory.getBean();
		jumsu.display();
		jumsu = (Jumsu)factory.getBean4();
		jumsu.display();
	}
}
