package com.samsung.homework01;

/**
 * 
 * @author 박서연
 * interface
 *
 */
public interface Jumsu {
	// 점수 총계를 구하는 메서드
	public void onTotal();
	// 점수 평균을 구하는 메서드
	public void onAvg();
	// console창에 출력하기 위한 메서드
	public void display();
}
